from flask import Flask, json
from flask import request,jsonify
from flask_sqlalchemy import SQLAlchemy
import pymysql

app = Flask(__name__)

# app.config['SQLALCHEMY_HOST'] = 'localhost'
# app.config['SQLALCHEMY_USER'] = 'root'
# app.config['SQLALCHEMY_PASSWORD'] = 'admin'
# app.config['SQLALCHEMY_DB'] = 'demo'

app.config["SQLALCHEMY_DATABASE_URI"]= "mysql+pymysql://root:admin@localhost/demo"
db = SQLAlchemy(app)


class Pateint_details(db.Model):
  
    id = db.Column(db.Integer, primary_key=True)
    DocumentType = db.Column(db.String(100))
    File_name = db.Column(db.String(100))
    Date = db.Column(db.String(20))
    Upload_document = db.Column(db.BLOB)
    Description = db.Column(db.String(500))
  

    def __init__(self, DocumentType, File_name, Upload_document ,Date, Description):
        self.DocumentType = DocumentType
        self.File_name = File_name
        self.Date = Date
        self.Description = Description
        self.Upload_document = Upload_document

@app.route("/insert_patient", methods=["POST"])
def insertPatient():
    try:
        data_req = request.get_json()
        print(data_req,"data_req")
        new_DocumentType = data_req.get("DocumentType",None)
        
        new_File_name = data_req.get("File_name",None)
        doc = data_req.get("UploadDocument",None)
        new_Upload_document = str.encode(doc)
        print(new_Upload_document,"new_Upload_document doc")
        new_Date = data_req.get("Date",None)
        new_Description = data_req.get("Description",None)

        patient = Pateint_details(new_DocumentType, new_File_name, new_Upload_document, new_Date, new_Description)
        db.session.add(patient)
        db.session.commit()
        

        return "<p>Data is updated</p>"
    except Exception as e:
        print(e,"EXption")
    


@app.route("/get_patient" , methods=["GET"])
def get_patient():
    all_patient = Pateint_details.query.all()

    output = []

    for patient in all_patient:
        patient_data = {}
        patient_data["id"] = patient.id
        patient_data['DocumentType'] = patient.DocumentType
        patient_data['File_name'] = patient.File_name
        patient_data['Date'] = patient.Date
        patient_data['Description'] = patient.Description
        # upd = patient.Upload_document
        # patient_data['Upload_document'] = upd.encode("utf-8")

        output.append(patient_data)

    return jsonify({"patients":output})

@app.route("/get_patient/<id>", methods = ["GET"])
def verify_patient(id):
    patient = Pateint_details.query.filter_by(id=id).first()
    if not patient:
        return jsonify({"message":"No user found"})
    patient_data = {}
    patient_data["id"] = patient.id
    patient_data['DocumentType'] = patient.DocumentType
    patient_data['File_name'] = patient.File_name
    patient_data['Date'] = patient.Date
    patient_data['Description'] = patient.Description
    # upd = patient.Upload_document
    # patient_data['Upload_document'] = upd.decode("utf-8")
  
   
    return jsonify({"patient":patient_data})

@app.route("/update_patient/<id>", methods = ["PUT"])
def update_patient(id):
    patient = Pateint_details.query.filter_by(id=id).first()
    if not patient:
        return jsonify({"message":"No user found"})

    data_req = request.get_json()
  
    new_DocumentType = data_req.get("DocumentType",None)
    new_File_name = data_req.get("File_name",None)
    new_Date = data_req.get("Date",None)
    new_Description = data_req.get("Description",None)
    doc = data_req.get("UploadDocument",None)
    if doc != None:
        new_Upload_document = str.encode(doc)
        print(new_Upload_document,"new_Upload_document doc")
        patient.Upload_document = new_Upload_document
 
    patient.DocumentType = new_DocumentType
    patient.File_name = new_File_name
    patient.Date = new_Date
    patient.Description = new_Description
    
    
    db.session.commit()
    
    return "<p> details have been updated successfully </p>"

@app.route("/delete_patient/<id>", methods = ["DELETE"])
def delete_patient(id):
    patient = Pateint_details.query.filter_by(id=id).first()
    if not patient:
        return jsonify({"message":"No user found"})
    db.session.delete(patient)
    db.session.commit()

    return "<P> Deleted successfully </P>"

if __name__ == "__main__":
    app.run(debug=True)