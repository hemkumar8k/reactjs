import React from "react";
import { Typography, TableHead, TableCell, TableRow } from "@material-ui/core";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import Button from '@material-ui/core/Button';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import { withStyles } from '@material-ui/styles';






class TableHeader extends React.Component {
  render() {
    const { classes } = this.props;
    const order = this.props.order
    const orderBy = this.props.orderBy
    return (
      <TableHead className="thBorder">
        <TableRow>
          {this.props.data &&
            this.props.data.map((dt, i) => (
              <TableCell key={i}
              sortDirection = {this.props.orderBy === dt.name ? this.props.order : false}
              >
              <div className="flex-text-icon">
              <TableSortLabel
              active={this.props.orderBy === dt.name}
              direction={this.props.orderBy === dt.name ? this.props.order : 'asc'}
              onClick={this.props.createSortHandler(dt.name)}
              >
                  {dt.name}
                 
                  {this.props.orderBy === dt.name ? (
                  <span className={classes.visuallyHidden}>

                  {this.props.order === 'desc' ? '' : ''}
                  </span>
                  
                 
                  ) : null}
                  
            </TableSortLabel>
               </div>
              </TableCell>
            ))}
        </TableRow>
      </TableHead>
    );
  }
}

export default TableHeader;
