export const PAGE_PATIENT = "patient";
export const PAGE_DASHBOARD = "dashboard";
export const PAGE_URLS = {};

PAGE_URLS[PAGE_PATIENT] = "/patient";
PAGE_URLS[PAGE_DASHBOARD] = "/";
