import React from "react";
import PatientManagement from "../pages/PatientManagement/PatientManagement";
import Dashboard from "../pages/Dashboard/Dashboard";

import {
  BrowserRouter,
  Switch,
  Route,
  Redirect
} from "react-router-dom";
import * as c from "../utils/constants/constants";

class Entry extends React.Component {

  render() {

    return (
      <BrowserRouter>
        <div >
          <Switch>
          <Route
               exact
               path={c.PAGE_URLS[c.PAGE_PATIENT]}
               render={(props) => (
            
                 <PatientManagement
                 {...props}  
               />
               )}
               />

          <Route
               exact
               path={c.PAGE_URLS[c.PAGE_DASHBOARD]}
               render={(props) => (
                 <Dashboard
                 {...props}  
               />
               )}
               />
            </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

export default Entry;
