import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  FormControlLabel,
  Radio,
  Divider,
  Button,
  RadioGroup,
  MenuItem,
  InputLabel,
  Select,
  FormControl,
} from "@material-ui/core";
import "./AddPatient.css";
import CloseIcon from "@material-ui/icons/Close";
import { withStyles } from '@material-ui/core/styles';



const today=new Date();
const todaydate=today.getDate() + "-"+ parseInt(today.getMonth()+1) +"-"+today.getFullYear();

const useStyles = ((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
    },
  },
  input: {
    display: 'none',
  },
}));


class AddPatient extends React.Component {

 
  render() {
    const { classes } = this.props;
    return (
      <>
        <Dialog open={this.props.data.add_open} className="pop-up-patient">
          <DialogTitle className="add-patient-title">
            <div className="flex-space-between">
              <p className="pop-title">{this.props.data.title}</p>
              <CloseIcon
                className="icon-style"
                style={{ color: "white" }}
                onClick={this.props.closePopup}
              />
            </div>
          </DialogTitle>
          <DialogContent>
            <div>
              {this.props.data.action === "edit" ||
              this.props.data.action === "add" ? (
                <>
                  <div className="flex-space-between">
                  {/* <div className="flex-flex-row"> */}
                  <FormControl className="input-field">
                      <InputLabel id="demo-simple-select-label">
                      DocumentType
                      </InputLabel>

                      <Select
                        name="DocumentType"
                        value={this.props.data.patient_details.DocumentType}
                        onChange={(event) => this.props.handleChange(event)}
                      >
                        <MenuItem value="BloodReport">Blood Report</MenuItem>
                        <MenuItem value="VaccinationReport">Vaccination Report</MenuItem>
                        <MenuItem value="Discharge_summary_mental_treatment">Discharge summary mental treatment</MenuItem>
                        <MenuItem value="video_call_recording">video call recording</MenuItem>

                   </Select>
                    </FormControl>
                    </div>
                    <div className="flex-space-between">
                    <input
                    accept="file"
                    // className={classes.input}
                    className="input-field"
                    id="contained-button-file"
                    // name = "Filename"
                    type="file"
                    
                    onChange={(event)=> this.props.FileStorage(event)}
                    //value= {this.props.data.patient_details.File_name}
                    // onChange={(event) => this.props.handleChange(event)}
                  />
                  

                  </div>
                  <div className="flex-space-between">
                    <TextField
                      autoComplete="off"
                      className="input-field"
                      label="Filename"
                      variant="outlined"
                      name="Filename"
                      value={this.props.data.patient_details.File_name}
                      onChange={(event) => this.props.handleChange(event)}
                    />
                    </div>

                    <div className="flex-space-between">
                    <TextField
                      autoComplete="off"
                      className="input-field"
                      label="Date"
                      variant="outlined"
                      name="Date"
                      value={this.props.data.patient_details.Date}
                      />
                  </div>
                  <div className="flex-space-between">
                    <TextField
                      autoComplete="off"
                      className="input-field"
                      label="Description"
                      variant="outlined"
                      name="Description"
                      value={this.props.data.patient_details.Description}
                      onChange={(event) => this.props.handleChange(event)}
                    />
                  
                  </div>

                  <Divider variant="middle" />
                  <div className="button-align">
                    <Button
                      className="button-field"
                      variant="contained"
                      color="primary"
                      onClick={() => this.props.saveChanges()}
                    >
                      Save
                    </Button>
                    <Button
                      className="button-field"
                      variant="outlined"
                      onClick={() => this.props.closePopup()}
                    >
                      Cancel
                    </Button>
                  </div>
                </>
              ) : (
                <div className="view-only">
                  <div className="flex-space-between">
                  {/* <div className="flex-flex-row"> */}
                    <div>

                    <div className="each-header-data">
                        <p className="label-font">id</p>
                        <p className="value-font">
                          {this.props.data.patient_details.id}
                        </p>
                      </div>

                      <div className="each-header-data">
                        <p className="label-font">DocumentType</p>
                        <p className="value-font">
                          {this.props.data.patient_details.DocumentType}
                        </p>
                      </div>

                      <div className="each-header-data">
                        <p className="label-font">UploadDocument</p>
                        <p className="value-font">
                          {this.props.data.patient_details.UploadDocument}
                        </p>
                      </div>

                      <div className="each-header-data">
                        <p className="label-font">Filename</p>
                        <p className="value-font">
                          {this.props.data.patient_details.File_name}
                        </p>
                      </div>
                      <div className="each-header-data">
                        <p className="label-font">Date</p>
                        <p className="value-font">
                          {this.props.data.patient_details.Date}
                        </p>
                      </div>

                      <div className="each-header-data">
                        <p className="label-font">Description</p>
                        <p className="value-font">
                          {this.props.data.patient_details.Description}
                        </p>
                      </div>
                      
                    
                    </div>
                  </div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }
}

export default  withStyles(useStyles) (AddPatient);
