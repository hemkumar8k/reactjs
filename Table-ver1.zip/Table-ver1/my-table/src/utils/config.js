export const patient_header = [
{name: "id"},  
{name: "DocumentType", sort_order: true, sort_icon: false },
{name: "Filename" , sort_order: true, sort_icon: false },
{name: "Date"},
{name: "Description"},
{ name: "Edit"},
{ name: "Delete"},
];




export const patient_data = [
{
    DocumentType:"BloodReport",
    UploadDocument:"C:\\Users\\hemkumar.t\\Downloads\\reports.txt",
    Filename:"reports.txt",
    Date:"30-7-2021",
    Description:"The demo description1"
},

{
    DocumentType:"vaccinationReport",
    UploadDocument:"C:\\Users\\hemkumar.t\\Downloads\\downarrow.png",
    Filename:"downarrow.png",
    Date:"30-7-2021",
    Description:"The demo description2"
},

{
    DocumentType:"bloodReport",
    UploadDocument:"C:\\Users\\hemkumar.t\\Downloads\\new.png",
    Filename:"new.png",
    Date:"30-7-2021",
    Description:"The demo description3"
},

];

localStorage.setItem('patient_data',JSON.stringify(patient_data));















