import './App.css';
import Entry from './container/Entry';
import './common.css';

function App() {
  return (
    <div className="App">
       <Entry />
    </div>
  );
}

export default App;
