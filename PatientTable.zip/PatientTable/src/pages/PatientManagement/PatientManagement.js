import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import { Table, TableContainer, Paper, Button } from "@material-ui/core";
import * as config from "../../utils/config";
import TableData from "./PatientTable/TableData/TableData";
import TableHeader from "./PatientTable/TableHeader/TableHeader";
import TablePage from "../../components/TablePage/TablePage";
import SearchBar from "../../components/SearchBar/SearchBar";
import AddPatient from "./AddPatient/AddPatient";
import "./PatientManagement.css";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { Description } from "@material-ui/icons";

const today=new Date();
const todaydate=today.getDate() + "-"+ parseInt(today.getMonth()+1) +"-"+today.getFullYear();



class PatientManagement extends React.Component {
  state = {
    add_open: false,
    patient_data: [],
    patient_header: [],
    patient_details : {
      DocumentType: "",
      UploadDocument: "",
      Filename: "",
      Date: todaydate,
      Description: ""
    },
    action: "",
    ref: "",
    title : "",
    startRecordNum : -1,
    recordsPerPage : 5,
    pageNum :0
  };
  componentDidMount = () => {
    this.setState({
      patient_header: config.patient_header,
      patient_data: config.patient_data,
      
    });
  };


  FileStorage=(event)=>{
    const file = event.target.files[0];
    const filename = file.name;
    console.log(file);
    console.log(event.target.file,"PAath");
    console.log(file.name,"FILE NAMEE");
    console.log("FILE STORAGE")
    console.log(this.state.patient_details,"PATIEENT DETTAILAAAAAAAAAAAAAAAAA")
    // this.setState({patient_details: {Filename:filename, Date:todaydate} });
    this.state.patient_details.Filename = filename;
    console.log(this.state.Description,"DESCRIPTION");
    console.log(this.state.DocumentType,"DOCUMENT TYPE");

  };
  
  handleChange = (event) => {
    //this.setState({ [event.target.name]: event.target.value });
    let val = event.target.value;
    let name = event.target.name;
    this.state.patient_details[name] = val;
    this.setState({ patient_details: this.state.patient_details });
  };
  handleChangePage = (event, newPage) =>{
    let recordsPerPage = this.state.recordsPerPage;
		this.setState({startRecordNum : recordsPerPage* newPage});
    this.setState({pageNum :  newPage});
        
  }
  saveChanges = () => {
    let patient_data_copy = [...this.state.patient_data];
    if (this.state.action === "add") {
      var new_data = this.state.patient_details;
      patient_data_copy.push(new_data);
    } else {
      patient_data_copy[this.state.ref] = this.state.patient_details;
    }
    this.setState({ add_open: false, patient_data: patient_data_copy });
  };
  openPopup = (action, id, ref) => {
    this.setState({ add_open: true, action: action, ref: ref });
    if (action === "add") {
      this.setState({
        patient_details : { DocumentType:"", UploadDocument:"", Date :todaydate, Description:""}, title : 'Add Patient'});
      } 
    
    else {
      action === 'edit' ? this.setState({title : 'Edit patient'}) : this.setState({title : 'View patient'})
      this.state.patient_data.forEach((data) => {
        console.log("EDIT")
        console.log(data.Filename,"Filename")
        console.log(data.DocumentType,"DocumentType EDIT")
        console.log(data.Date,"DATE EDIT")
        console.log(data.Description,"DESCRIPTION EDIT")
        id === data.DocumentType &&
          this.setState({
            patient_details : {
              DocumentType:data.DocumentType,
              UploadDocument:data.UploadDocument,
              Filename:data.Filename,
              Date:data.Date,
              Description:data.Description,
            }
          });
      });
    }
  };
   

   closePopup = () => {
    this.setState({ add_open: false });
  };
  
  deleteAlert = (index) => {

    confirmAlert({
      title: 'Are you sure to delete this',
      // message: 'Are you sure to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => this.deleteData(index)
        },
        {
          label: 'No',
          onClick: () => this.componentDidMount()
        }
      ]

    });
    
  }
  

  deleteData = (index) => {
    index = index
    let deletedData = [...this.state.patient_data];
    deletedData.splice(index, 1);
    this.setState({ patient_data: deletedData });
    this.setState({add_open:false})
  };


  render() {
    return (
      <div>
        <Navbar />
        <div className="full-view">
          <div>
            <p className = 'page-title'>Patient details</p>
          </div>
          <div className="flex-space-between">
            <SearchBar />
            <Button
              variant="contained"
              color="primary"
              onClick={() => this.openPopup("add")}
            >
              Add
            </Button>
          </div>
          <br />
          <TableContainer component={Paper}>
            <Table stickyHeader aria-label="customized table">
              <TableHeader data={this.state.patient_header} />
              <TableData
                data={this.state.patient_data}
                openPopup={this.openPopup}
                deleteAlert={this.deleteAlert}
                startRecordNum = {this.state.startRecordNum}
                recordsPerPage = {this.state.recordsPerPage}
              />
            </Table>
          </TableContainer>
          <TablePage
              count ={this.state.patient_data.length}
              recordsPerPage = {this.state.recordsPerPage}
              pageNum = {this.state.pageNum}
              handleChangePage = {this.handleChangePage}
          />
        </div>
        <Footer />
        <AddPatient
          data={this.state}
          FileStorage={this.FileStorage}
          handleChange={this.handleChange}
          saveChanges={this.saveChanges}
          closePopup={this.closePopup}
  
        />
       
      </div>
    );
  }
}

export default PatientManagement;
