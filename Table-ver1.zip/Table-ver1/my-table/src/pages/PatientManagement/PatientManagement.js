import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import { Table, TableContainer, Paper, Button } from "@material-ui/core";
import * as config from "../../utils/config";
import TableData from "./PatientTable/TableData/TableData";
import TableHeader from "./PatientTable/TableHeader/TableHeader";
import TablePage from "../../components/TablePage/TablePage";
import SearchBar from "../../components/SearchBar/SearchBar";
import AddPatient from "./AddPatient/AddPatient";
import "./PatientManagement.css";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { Description } from "@material-ui/icons";
import axios from "axios";


const today=new Date();
const todaydate=today.getDate() + "-"+ parseInt(today.getMonth()+1) +"-"+today.getFullYear();



class PatientManagement extends React.Component {
  state = {
    add_open: false,
    patient_data: [],
    patient_header: [],
    patient_file:"",
    patient_details : {
      id:"",
      DocumentType: "",
      UploadDocument: "",
      File_name: "",
      Date: todaydate,
      Description: ""
    },
    action: "",
    ref: "",
    title : "",
    startRecordNum : -1,
    recordsPerPage : 5,
    pageNum :0
  };

  gethandler = () =>{
    axios.get("http://127.0.0.1:5000/get_patient"   
    
      ).then(response=>{
        this.setState({patient_data:response.data.patients})
      console.log(response.data.patients,"GET REQUEST AXIOS RESPONSE FROM MSQL DB")
      

    }).catch(error=>{
      console.log(error,"ERRO GETTING API AXIOS")
    })
  };
  componentDidMount = () => {
    this.setState({
       patient_header: config.patient_header,
       //patient_data: config.patient_data,
      
     });

    this.gethandler()

  };


  FileStorage=(event)=>{
    const file = event.target.files[0];
    const filename = file.name;

    console.log(file,"FILE");

    
    // this.setState({patient_details: {Filename:filename} });
    this.state.patient_details.File_name = filename;
    console.log(this.state.patient_details.File_name ,"this.state.patient_details.File_name ")
    this.state.patient_file = file;
    this.getBase64(file, (result) => {
      this.state.patient_details.UploadDocument = result;
    });
  };

  
  getBase64(patient_file, cb) {
    let reader = new FileReader();
    reader.readAsDataURL(patient_file);
    reader.onload = function () {
        cb(reader.result)
    };
    reader.onerror = function (error) {
        console.log('Error: ', error);
    };
}

  
  handleChange = (event) => {
    //this.setState({ [event.target.name]: event.target.value });
    let val = event.target.value;
    let name = event.target.name;
    this.state.patient_details[name] = val;
    this.setState({ patient_details: this.state.patient_details });
  };
  handleChangePage = (event, newPage) =>{
    let recordsPerPage = this.state.recordsPerPage;
		this.setState({startRecordNum : recordsPerPage* newPage});
    this.setState({pageNum :  newPage});
        
  };
  postData= (new_data) =>{
    axios.post("http://127.0.0.1:5000/insert_patient",new_data).
    then(response=>{console.log(response,"RESPONSE IN AXIOS ")})
  };

  putData = (updated_data,id) => {
    let url = "http://127.0.0.1:5000/update_patient"
    axios.put(`${url}/${id}`, updated_data).then((response)=>console.log(response,"PUT RESPONSE"))

  };
  
  saveChanges = () => {
    let patient_data_copy = [...this.state.patient_data];
    
    if (this.state.action === "add") {
      var new_data = this.state.patient_details;
      console.log(new_data,"NEW_DATA")
      this.postData(new_data)
      // patient_data_copy.push(new_data);
    } 
    else {
      // patient_data_copy[this.state.ref] = this.state.patient_details;
      patient_data_copy = this.state.patient_details;

      console.log(patient_data_copy,"patient_data_copy edit")
      this.putData(patient_data_copy,patient_data_copy.id)
    }
    // else{
    //   console.log("hi")
    // }
    // this.setState({ add_open: false, patient_data: patient_data_copy });
    this.setState({ add_open: false});
  };
  openPopup = (action, id, ref) => {
    this.setState({ add_open: true, action: action, ref: ref });
    if (action === "add") {
      this.setState({
        patient_details : { DocumentType:"", UploadDocument:"", File_name:"", Date :todaydate, Description:""}, title : 'Add Patient'});
      } 
    
    else {
      action === 'edit' ? this.setState({title : 'Edit patient'}) : this.setState({title : 'View patient'})
      this.state.patient_data.forEach((data) => {
        console.log("EDIT")
        console.log(data.File_name,"File_name")
        console.log(data.id,"id")
        console.log(data.DocumentType,"DocumentType EDIT")
        console.log(data.Date,"DATE EDIT")
        console.log(data.Description,"DESCRIPTION EDIT")
        console.log(id,"id",data.id,"datata.id")
        id === data.id &&
          this.setState({
            patient_details : {
              id:data.id,
              DocumentType:data.DocumentType,
              UploadDocument:data.Upload_document,
              File_name:data.File_name,
              Date:data.Date,
              Description:data.Description,
            }
          });
      });
      
    }
  };
   

   closePopup = () => {
    this.setState({ add_open: false });
  };
  
  deleteAlert = (id) => {

    confirmAlert({
      title: 'Are you sure to delete this',
      // message: 'Are you sure to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => this.deleteData(id)
        },
        {
          label: 'No',
          onClick: () => this.componentDidMount()
        }
      ]

    });
    
  }
  

  deleteData = (id) => {
    
    let url = "http://127.0.0.1:5000/delete_patient"
    axios.delete(`${url}/${id}`)
    .then((response)=>console.log(response,"DELTE"));
    // index = index
    // let deletedData = [...this.state.patient_data];
    // deletedData.splice(index, 1);
    // this.setState({ patient_data: deletedData });
    // this.setState({add_open:false})
  };


  render() {
    return (
      <div>
        <Navbar />
        <div className="full-view">
          <div>
            <p className = 'page-title'>Patient details</p>
          </div>
          <div className="flex-space-between">
            <SearchBar />
            <Button
              variant="contained"
              color="primary"
              onClick={() => this.openPopup("add")}
            >
              Add
            </Button>
          </div>
          <br />
          <TableContainer component={Paper}>
            <Table stickyHeader aria-label="customized table">
              <TableHeader data={this.state.patient_header} />
              <TableData
                data={this.state.patient_data}
                openPopup={this.openPopup}
                deleteAlert={this.deleteAlert}
                startRecordNum = {this.state.startRecordNum}
                recordsPerPage = {this.state.recordsPerPage}
              />
            </Table>
          </TableContainer>
          <TablePage
              count ={this.state.patient_data.length}
              recordsPerPage = {this.state.recordsPerPage}
              pageNum = {this.state.pageNum}
              handleChangePage = {this.handleChangePage}
          />
        </div>
        <Footer />
        <AddPatient
          data={this.state}
          FileStorage={this.FileStorage}
          handleChange={this.handleChange}
          saveChanges={this.saveChanges}
          closePopup={this.closePopup}
  
        />
       
      </div>
    );
  }
}

export default PatientManagement;
